"""Meta-search catalog MCP."""
